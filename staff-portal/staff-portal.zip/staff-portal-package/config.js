var CONFIG = {
    API_URL: 'https://veterans-support-api.onrender.com'
};
